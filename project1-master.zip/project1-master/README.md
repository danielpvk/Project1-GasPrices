##Fuel prices by locaton 
